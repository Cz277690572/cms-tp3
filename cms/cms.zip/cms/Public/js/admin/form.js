/**
 * 表单功能类
 */

var form  = {
    submit : function()
}