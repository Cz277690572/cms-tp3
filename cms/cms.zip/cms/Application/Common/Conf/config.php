<?php
return array(
	//'配置项'=>'配置值'

	//URL地址不区分大小写
	'URL_CASE_INSENSITIVE' => true,
	'URL_MODEL' => 0,
	// 加载扩展配置文件
	'LOAD_EXT_CONFIG' => 'db',
	// 给密码加盐
	'MD5_PRE' => 'abin_cms',
	// 静态文件的默认后缀
	'HTML_FILE_SUFFIX' => '.html',
);